function selectCard(n){
    const cards = document.querySelectorAll('.card');

    cards.forEach(c=>{
        c.classList.remove('active');
        c.querySelector('input').checked = false;

        let opt = c.querySelector('.options');
        if(opt){
            opt.style.display = 'none';
        }
    });

    const selected = cards[n-1];
    selected.classList.add('active');
    selected.querySelector('input').checked = true;

    let opt = selected.querySelector('.options');
    if(opt){
        opt.style.display = 'block';
    }

    let price = selected.getAttribute("data-price");
    document.getElementById("total").innerHTML = "Total : ₹" + price + ".00";
}
